# TruxFlow — Load & Pay Manager (standalone version)

This is a standalone copy of the app that runs entirely from static files —
no server, no build step, **no account or backend to configure**. Upload it
to GitHub Pages and it just works.

## What's in this folder

- `index.html` — loads React and the Excel-import library from CDNs, then loads `app.js`
- `app.js` — the app itself
- `manifest.json` + `service-worker.js` — what makes "Add to Home Screen" open with no address bar and work offline-ish
- `icons/` — your TruxFlow app icons

## Step 1 — Create a GitHub repository (~2 min)

1. Go to **github.com** → sign up (free) if you don't have an account.
2. Click the **+** icon top-right → **New repository**.
3. Name it anything (e.g. `truxflow-app`) → keep it **Public** → **Create repository**.

## Step 2 — Upload the files (~2 min)

1. On your new empty repo's page, click **uploading an existing file** (or "Add file → Upload files").
2. Drag in **every file and folder** from this folder — `index.html`, `app.js`, `manifest.json`, `service-worker.js`, and the `icons` folder.
3. Scroll down, click **Commit changes**.

## Step 3 — Turn on GitHub Pages (~2 min)

1. In your repo: **Settings** (top tab) → **Pages** (left sidebar).
2. Under "Build and deployment," set **Source** to **Deploy from a branch**.
3. Set **Branch** to `main`, folder to `/ (root)` → **Save**.
4. Wait 1-2 minutes, refresh — you'll see a green box with your live URL, like `https://yourusername.github.io/truxflow-app/`.

## Step 4 — Open it and install it (~1 min)

1. Open that URL on your phone.
2. No login screen — it opens straight into the app.
3. **iPhone (Safari)**: tap Share → Add to Home Screen.
   **Android (Chrome)**: tap ⋮ → Add to Home screen / Install app.
4. Open it from the home screen icon — full screen, no browser bar.

That's it. No Firebase, no sign-up, no config files to edit.

## The trade-off you're accepting by skipping Firebase

Your data (loads, trips, drivers, etc.) is saved using your **browser's local storage** — it lives only on that one phone/browser, not in the cloud. In practice that means:

- ✅ It's genuinely simpler — zero setup, works the moment you upload it.
- ✅ It survives closing the app, restarting your phone, going offline.
- ⚠️ It will **not** show up if you open the same URL on a different phone, tablet, or computer — each device keeps its own separate data.
- ⚠️ If you ever clear your browser's site data/history for this site, it's gone. Be mindful about not clearing site data for this site on that device.

## Want cross-device sync later?

If down the road you outgrow single-device storage — say a dispatcher and an owner both need to see the same data, or you want it on your phone AND desktop — come back and I can re-add the Firebase sync version, and we can troubleshoot whatever went wrong this time. For now, this simpler version gets you actually using the app today.

## Getting future updates onto your live app

Whenever you get an updated `app.js` from me:
1. Go to your GitHub repo → click `app.js` → pencil (edit) icon.
2. Delete everything, paste in the new version → **Commit changes**.
3. GitHub Pages updates automatically within a minute or two — refresh your phone app to see it.

Your saved data isn't affected by updating `app.js` — it lives in the browser separately from the code.
